package chat

import (
	"context"
	"database/sql"
	"time"
)

// Room is a place to talk.
type Room struct {
	ID        int64
	Name      string
	CreatedAt time.Time
}

// Rooms lists every room, oldest first.
func Rooms(ctx context.Context, db *sql.DB) ([]Room, error) {
	rows, err := db.QueryContext(ctx,
		`SELECT id, name, created_at FROM rooms ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var rooms []Room
	for rows.Next() {
		var room Room
		err := rows.Scan(&room.ID, &room.Name, &room.CreatedAt)
		if err != nil {
			return nil, err
		}
		rooms = append(rooms, room)
	}
	return rooms, rows.Err()
}

/* The scaffold's own helpers stay below. */
func open(path string) (*sql.DB, error) {
	return sql.Open("sqlite", path+"?_pragma=foreign_keys(1)")
}
